# EcomLens – Business at a Glance (Tableau, Dmart): Presenter's Guide

This guide explains the Tableau workbook `EcomLens - Business at a Glance.twbx`. It covers what the dashboard answers, where its numbers come from, how each chart is built and what the data says. It is written for presenting, not for engineers.

---

## 1. Executive Summary

EcomLens is a six-page Tableau dashboard about **Dmart**, an Indian online grocery and household-goods retailer. It covers **25,000 orders** from **24,814 customers** in four states (Maharashtra, Andhra Pradesh, Gujarat and Telangana) between **2021 and 2023**. All money is in Indian rupees (₹).

Each page answers one group of business questions:

| Page | Business question it answers |
|---|---|
| **Overview** | How big is the business, is it growing, and where does revenue come from? |
| **Sales** | What are the monthly, quarterly and yearly trends? Which products, cities and channels sell most? When are the peak and low months? |
| **Customers** | Who are the high-value customers? How many are churning? Do customers come back? |
| **Products** | Which products earn the most, rate best and get returned most? |
| **Fulfillment** | How long does delivery take, how often is it late, and where are orders cancelled? |
| **Payments** | How do customers pay, how many payments are still pending, and where do returns concentrate? |

Every page has the same layout:

- a navy header with page buttons,
- a row of six KPI cards,
- two or three rows of charts,
- a filter panel on the right.

---

## 2. Data & Metric Logic

### 2.1 Where the data comes from

One Excel file feeds the workbook: **`Dmart+Dataset_Tableau.xlsx`**. It has one row per order, and its key columns are:

- **Customer:** Customer ID, Customer Age, Gender, Subscription (Freepass / Premium / Premium Plus).
- **Product:** Product Name (22 products), Category (Local / Branded / Imported), MRP, Discount Price.
- **Location:** State, City (40 cities).
- **Order journey:** Order Date, Delivery Date, Ship Mode (Free / Priority / Express plus), Order Status (Delivered / Shipped / Cancelled / Returned).
- **Money:** Total Order Value, Shipping Charges, Payment Method, Payment Status.
- **Behaviour:** Rating, Marketing/Advertisement channel, No of Clicks, Time Spent on Website.

### 2.2 How the data was prepared

Before the data reached Tableau, a short Python script (`src/prepare_data.py`) cleaned the file and added helper columns. It then saved everything as a Tableau data extract (`ecomlens.hyper`, table **Dmart Orders**). The extract is packed inside the `.twbx`, so the workbook opens without the Excel file.

| Helper column | What it means |
|---|---|
| **Revenue** | The order's Total Order Value. Cancelled orders have no value, so they count as orders but add no revenue. |
| **Discount Amount** | MRP minus the discounted selling price. |
| **Year / Quarter** | Taken from the order date. |
| **Is Cancelled / Is Returned / Is Delivered / Is Shipped** | A 1 or 0 flag per order. Adding up the flags counts orders, and averaging them gives a share. |
| **Delivery Days** | Days from order date to delivery date, for Delivered and Shipped orders only. |
| **Is Delayed** | 1 if delivery took **more than 7 days**. |
| **Customer Type** | "Repeat" if the customer has 2+ orders, otherwise "One-time". |
| **Is First Order** | 1 on a customer's first order. |
| **Is Churned** | 1 if the customer's last order was more than **180 days** before 30 Dec 2023. |
| **R / F / M Score, RFM Segment** | Loyalty scoring (see 2.4). |
| **Value Tier** | "High Value" if the customer is in the top 25% by total spend. |

### 2.3 Calculated fields in Tableau

These formulas live in the workbook and are recalculated whenever a filter changes. The full-data values are listed in `output/reference_numbers.md`.

| Metric | Formula in plain English | Full data |
|---|---|---|
| Revenue | Sum of Revenue (KPI shows ₹ millions) | ₹16.95M |
| Orders | Count of orders | 25,000 |
| Customers | Distinct customer IDs | 24,814 |
| Avg Order Value | Revenue ÷ orders | ₹678 |
| Delivered Rate | Delivered orders ÷ all orders | 52.0% |
| Cancel Rate / Return Rate | Cancelled (or returned) orders ÷ all orders | 7.1% / 5.4% |
| Avg Discount | Total discount ÷ total MRP | 27.4% |
| Avg Delivery Days | Average Delivery Days | 6.3 days |
| Delay Rate | Share of delivered or shipped orders over 7 days | 42.5% |
| Repeat Rate | Customers with 2+ orders ÷ all customers | 0.7% |
| Churn Rate | Churned customers ÷ all customers | 83.1% |
| Paid Rate | Orders with payment status Paid ÷ all orders | 69.9% |
| Avg Rating, Avg Clicks, Avg Time on Site | Simple averages | 3.01, 50.4, 10.2 min |
| Peak Flag | Ranks months by revenue: top 5 "Peak month", bottom 5 "Low month" | – |

### 2.4 RFM segments

Each customer gets three scores:

- **R (recency):** how recently they ordered.
- **F (frequency):** how often they ordered.
- **M (monetary):** how much they spent.

Almost every Dmart customer has exactly one order, so F only separates repeat buyers (score 5) from everyone else (score 1). The segments are:

- **Champions:** 2+ orders, ordered in the last 180 days, high spend.
- **Loyal:** 2+ orders, recent.
- **High Value:** high spend, ordered within a year.
- **Recent:** one order in the last 90 days.
- **At Risk:** last order within a year.
- **Hibernating:** no order for more than a year.

---

## 3. Dashboard & Chart Breakdown

### Overview

- **KPIs:** Revenue, Orders, Customers, Avg order value, Delivered, Cancel rate.
- **Monthly revenue:** area chart of revenue per month.
- **Revenue by year:** one column per year.
- **Revenue by state:** a filled map of the four states.
- **Orders by status:** donut showing Delivered, Shipped, Cancelled and Returned orders.
- **Revenue by category:** donut showing Local, Branded and Imported.
- **Revenue by marketing channel:** bar chart.

### Sales Analysis

- **KPIs:** Revenue, Orders, Avg order value, Avg discount, Avg shipping charge, Products.
- **Monthly revenue, 5 peak and 5 low months:** green bars are the best five months and red bars the worst five.
- **Quarterly and yearly revenue:** quarters grouped under each year.
- **Revenue by category:** donut.
- **Top 10 products, Revenue by state, Top 10 cities:** bar charts sorted by revenue.
- **Revenue by marketing channel; Avg discount by category; Avg order value by subscription:** compare channels, discount depth and plan types.

### Customer Behavior

- **KPIs:** Customers, Repeat customers, Churn rate, High-value customers, Avg clicks, Avg time on site.
- **Customers by RFM segment:** bar chart.
- **Recency vs spend score:** heat map of customer counts.
- **First vs repeat orders by month:** line chart (teal for first orders, orange for repeat).
- **Top 10 high-value customers:** table of revenue, days since last order and order count.
- **Customers by marketing channel:** columns.
- **Avg minutes on site by subscription:** columns.
- **Orders by age band:** columns.
- **Gender, Subscription and One-time vs repeat:** three donuts.

### Product Performance

- **KPIs:** Products, Avg rating, Return rate, Cancel rate, Avg discount, Avg selling price.
- **Revenue vs avg rating:** one bubble per product, colored by category and sized by orders.
- **Products sized by revenue, colored by return rate:** tree map. Darker orange means more returns.
- **Avg clicks by category:** columns.
- **Product scorecard:** table of revenue, rating and return rate for every product.
- **Top 10 products by returned orders:** bar chart.
- **Avg rating by category:** columns.

### Fulfillment and Delivery

- **KPIs:** Avg delivery days, Delayed orders, Delivered, In transit, Cancellations, Avg shipping charge.
- **Avg delivery days by ship mode:** bar chart.
- **Delay rate by state:** map.
- **Orders by status each month:** stacked columns.
- **Cancellations by category:** donut.
- **Avg shipping charge by ship mode:** bar chart.
- **Delay rate by state and ship mode:** heat map.

### Payments and Returns

- **KPIs:** Paid orders, Pending payments, Cancel rate, Cancellations, Return rate, Returned orders.
- **Orders by payment method:** donut. Cancelled orders have no payment method, so they are left out.
- **Orders by payment status:** bar chart.
- **Cancellations (bars) and returns (line) by month:** combined chart.
- **Revenue by payment method; Return rate by payment method:** bar charts.
- **Return rate by category and ship mode:** heat map.

---

## 4. Interactivity & Filters

- **Page buttons:** the navy header holds six buttons (Overview, Sales, Customers, Products, Fulfillment, Payments). The current page is highlighted in blue, and clicking another button jumps to that page.
- **Filters:** **Year**, **Category** and **State** sit in the right-hand panel. Each is a multi-select dropdown, and they are shared by every worksheet. A choice made on one page applies to all six pages and every KPI.
- **Tooltips:** hovering over any mark shows its exact values. Several charts add extra detail, such as orders per month on the trend charts and delivery days on the delay map.
- **Peak and low months** are re-ranked within whatever years you select. Picking only 2023, for example, shows that year's five best and worst months.

---

## 5. Presentation Talking Points

1. **Revenue is flat at about ₹5.5–5.7M a year.** It grew 3.7% from 2021 to 2022 and dipped slightly in 2023. Growth needs a new lever rather than more of the same.
2. **Local products carry the business.** They bring in half of all revenue, against 30% for Branded and 20% for Imported. All four states contribute almost equally, each around ₹4.2–4.3M.
3. **Instagram is the strongest channel** at ₹5.76M, followed by Facebook at ₹4.22M. TV brings in the least (₹1.40M), so it is the first place to question ad spend.
4. **Customers rarely come back.** Only 0.7% of customers ordered twice, and 83% have not ordered in the last 180 days. Retention, through subscriptions, reminders and loyalty offers, is the biggest opportunity.
5. **Free shipping is the delay problem.** Free orders take 8.5 days on average and 75% of them are late, while Priority (2.5 days) and Express plus (4.5 days) are never late. The delay rate is about 42–43% in every state, so the cause is the ship mode, not the region.
6. **Discounts are uniform.** Every category averages about 27% off MRP, and ratings are flat at about 3.0 out of 5. Neither discounts nor ratings currently separate winners from losers.
7. **Payments are healthy but not finished.** 70% of orders are paid, 18% are pending, and cancellations (7.1%) and returns (5.4%) are spread evenly across categories and payment methods. Debit and Credit cards cover about two thirds of orders.
8. **Limits to state up front:**
   - There is no stock or inventory data, so inventory trends cannot be shown.
   - There is no return-reason field.
   - Repeat-customer analysis is limited because almost everyone orders once.
