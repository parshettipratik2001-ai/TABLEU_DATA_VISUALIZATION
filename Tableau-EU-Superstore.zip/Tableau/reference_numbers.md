# Reference numbers

Totals over the full data with no filters applied. Use them to check the dashboards after opening or refreshing.

## Tableau: Dmart (India, 2021-2023)

| Metric | Value |
| --- | --- |
| Revenue (INR) | 16,954,109 |
| Orders | 25,000 |
| Customers | 24,814 |
| Avg order value (INR) | 678 |
| Delivered share | 52.0% |
| Cancel rate | 7.1% |
| Return rate | 5.4% |
| Delay rate (over 7 days) | 42.5% |
| Avg delivery days | 6.3 |
| Repeat customers | 0.7% |
| Churn rate | 83.1% |
| Paid rate | 69.9% |
| Avg rating | 3.01 |

## Power BI: EU Superstore (2015-2018)

| Metric | Value |
| --- | --- |
| Sales (EUR) | 2,938,089 |
| Profit (EUR) | 372,830 |
| Profit ratio | 12.7% |
| Orders | 4,596 |
| Customers | 795 |
| Avg order value (EUR) | 639 |
| Orders per customer | 5.8 |
| Return rate (returned sales / sales) | 7.0% |
| Returned sales (EUR) | 204,920 |
| Returned orders | 284 |
| Late shipment rate | 33.4% |
| Avg ship days | 4.0 |
| Churn rate | 26.7% |
| Products | 1,856 |
| Stagnant products | 380 |
