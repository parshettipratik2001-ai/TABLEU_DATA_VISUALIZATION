# EcomLens – Business at a Glance: Findings Report

**What we were asked to do, what we built, what we learned, and what we recommend.**

---

## 1. The task in one paragraph

The assignment asked for an "EcomLens – Business at a Glance" dashboard covering five areas:

- Sales
- Customer behaviour
- Product performance
- Order fulfillment
- Payments and returns

Two datasets were provided. Following the latest instruction, each one gets its own tool:

| Tool | Dataset | Scope |
|---|---|---|
| **Tableau** | **Dmart** | Indian online grocery retailer: 25,000 orders, 24,814 customers, 2021–2023, ₹ |
| **Power BI** | **EU Superstore** | European office, furniture and tech retailer: 4,596 orders, 795 customers, 15 countries, 2015–2018, € |

Both dashboards follow the client's example screenshots: KPI cards on top, charts below, a filter panel on the right, and six linked pages.

---

## 2. What we solved

### 2.1 Every objective in the brief is covered

| Objective from the brief | Tableau (Dmart) | Power BI (EU Superstore) |
|---|---|---|
| **1. Sales:** monthly, quarterly and yearly trends; top products, categories and regions; peak and low periods | Sales page, with green/red peak and low months | Sales page, with green/red peak and low months |
| **2. Customers:** RFM segments, loyal and high-value customers, churn, new-customer trend | Customers page | Customers page |
| **3. Products:** high revenue vs high returns; inventory trends; stagnant products | Products page | Products page, including a stagnant-products list |
| **4. Fulfillment:** delivery time and delays; performance by shipping partner or region; cancellations and returns | Fulfillment page | Fulfillment page |
| **5. Payments and returns:** preferred payment methods; refund trends and reasons | Payments page | Returns page (no payment data exists) |
| **Deliverable:** a Tableau dashboard titled "EcomLens – Business at a Glance" | `EcomLens - Business at a Glance.twbx` | `powerbi/EcomLens.pbip` |

A few items in the brief **cannot be answered by the data**, and the dashboards say so on screen rather than guessing:

- **Inventory trends:** neither dataset has stock levels.
- **Reasons for returns:** neither dataset records a return reason. We show *where* returns happen instead.
- **Payment methods for EU:** EU Superstore has no payment fields.
- **Shipping partners:** neither dataset names a courier. We use ship mode (for example Free vs Priority) as the closest substitute.


---

## 3. What we learned: Dmart (Tableau)

**Headline: Dmart is a stable business with a serious retention problem and a delivery problem that comes from one ship mode.**

### Sales
- Revenue is **₹16.95M** from 25,000 orders, with an average order of **₹678**.
- Revenue is **flat**: ₹5.53M in 2021, ₹5.73M in 2022 and ₹5.70M in 2023. Every quarter falls between ₹1.32M and ₹1.50M, so there is no strong seasonality. The best month was August 2022 (₹539K) and the weakest was February 2021 (₹408K).
- **Local products bring in half of revenue** (50%), against 30% for Branded and 20% for Imported.
- The four states are almost equal, each at ₹4.2–4.3M. The top cities are Suryapet, Vadodara and Guntur.
- The 22 products sit in a narrow band of ₹0.71–0.83M each. Harpic Bathroom Cleaner, Parle Nutricrunch and Wagh Bakri Masala Tea lead; VSR Channa Dal and Amul Butter trail.
- **Instagram is the strongest marketing channel** (₹5.76M), followed by Facebook (₹4.22M). **TV is the weakest** (₹1.40M).

### Customers
- **Almost nobody comes back.** Only **0.7%** of customers ordered more than once.
- **83% have churned**, meaning no order in the last 180 days.
- In RFM terms, about two thirds of customers are "Hibernating" (no order for over a year). There are only 25 "Champions" and 18 "Loyal" customers.
- Behaviour is the same across subscription tiers (Freepass, Premium, Premium Plus): about ₹650–700 per order and about 10 minutes on site. The paid subscriptions do not change how people buy.

### Products
- Every category averages about **27% off MRP**, and every category's rating is about **3.0 out of 5**. Neither discount nor rating explains why one product sells more than another.
- Return rates (about 5.4%) and cancellation rates (about 7%) are similar across all categories.

### Fulfillment
- 52% of orders are delivered, 35% are still in transit, 7% are cancelled and 5% are returned.
- Average delivery takes **6.3 days**, and **42.5% of deliveries are late** (over 7 days).
- **Free shipping causes all the delays.** Free orders take 8.5 days on average and 75% are late. Priority (2.5 days) and Express plus (4.5 days) are never late. The delay rate is the same in every state, so the cause is the ship mode, not the location.

### Payments and returns
- **70% of orders are paid** and **18% are still pending**.
- **Debit (37%) and Credit (28%) cards** are the preferred methods, followed by UPI (14%), Netbanking (9%) and COD (5%).
- Return rates are similar for every payment method (5.3–6.7%), with Netbanking slightly highest.

---

## 4. What we learned: EU Superstore (Power BI)

**Headline: EU Superstore is growing fast with a loyal customer base, but discounting and Furniture eat into profit, and one shipment in three is late.**

### Sales
- Sales are **€2.94M**, with **€373K profit** (a **12.7% margin**).
- **Strong growth:** sales rose from €478K in 2015 to €652K, €765K and then **€1.04M in 2018 (+36%)**. Profit roughly doubled, from €61K to €129K.
- **Clear seasonality:** Q3 and Q4 are the strongest quarters every year and Q1 the weakest. All five peak months are in 2018 (the best was August, €150K) and all five low months are in 2015.
- **Central region dominates** with €1.72M, against about €0.6M each for North and South. The top countries are France (€859K), Germany (€629K) and the UK (€529K).
- Consumers bring in 52% of sales, Corporate 31% and Home Office 17%. Margins are similar across these customer segments (12–13%).

### Customers
- 795 customers placed **5.8 orders each** on average and spent about **€3,700 each**.
- **Churn is low at 27%** (30% in the North).
- RFM shows a healthy spread: 108 Champions, 120 Loyal and 128 Potential Loyalists. **150 customers are "At Risk"**: they used to buy often but have gone quiet.
- **New customer acquisition has almost stopped.** First-time customers fell from 533 in 2015 to 198, then 59, then just **5 in 2018**. All the recent growth comes from existing customers buying more.

### Products
- There are 1,856 products. **380 are stagnant**: they sold before 2018 but not in 2018.
- **Margin by category:** Office Supplies 15.3%, Technology 13.0%, **Furniture only 8.8%**.
- **Tables are the only loss-making sub-category**, at –€21K profit.
- The top product is the Nokia Smart Phone (€33.5K), followed by the Hoover and Hamilton Beach stoves.

### Fulfillment
- Average time to ship is **4.0 days**, and **33.4% of shipments are late** against what the ship mode promises.
- **Premium shipping is the least reliable.** First Class and Second Class are late about 40% of the time, against 32% for Standard Class and 4% for Same Day.
- The North has the worst late rate (37%) and the South the best (29%).

### Returns and discounts
- **7% of sales are returned**: €205K across 284 orders.
- **The South returns the most** (9.5% of sales, against about 6% in Central and North).
- **Discounts destroy profit:**

| Discount band | Profit margin |
|---|---|
| No discount | +25% |
| 0–10% | +17% |
| 10–20% | +9% |
| 20–40% | **–24%** |
| 40%+ | **–60%** |

---

## 5. Recommendations

### Dmart
1. **Fix retention first.** With 0.7% repeat buyers and 83% churn, winning back even a small share of past customers is worth more than any new campaign. Options include reorder reminders, first-repeat-order coupons, and making the subscription tiers actually reward repeat buying.
2. **Fix or reprice Free shipping.** It causes all of the late deliveries. Either set a realistic delivery promise for Free orders or nudge customers to Priority with a small fee.
3. **Move marketing money from TV to Instagram and Facebook.** TV brings in the least revenue and the fewest customers.
4. **Rethink blanket discounts.** A flat ~27% discount on everything doesn't change ratings or sales mix. Targeted offers would cost less.
5. **Chase the 18% pending payments.** That money has been earned but not collected.

### EU Superstore
1. **Cap discounts at about 20%.** Every band above that loses money, so this is the biggest single profit lever.
2. **Fix or drop loss-making Tables**, and review Furniture pricing.
3. **Restart customer acquisition.** Growth currently depends entirely on existing customers, which will not last.
4. **Win back the 150 "At Risk" customers** with targeted offers, especially in the North where churn is highest.
5. **Make premium shipping keep its promise.** First and Second Class are late 40% of the time, which undermines why customers pay for them.
6. **Investigate returns in the South**, and **clear or delist the 380 stagnant products.**

---

## 6. Limits to mention when presenting

- There is **no stock, return-reason or courier data** in either dataset, so inventory trends and the reasons behind returns cannot be analysed.
- **Dmart customers almost all order once**, so loyalty segmentation (RFM) is less informative there than for EU Superstore.
- **EU Superstore has no payment data**, so its "Payments and Returns" page covers returns and discounts only.
- The two businesses use different currencies, countries and years, so **they should not be compared directly**. Each is analysed on its own terms.

---
